#_*_coding:utf-8 _*_
# @Time : 2021/11/27 12:14
# @Author : 郑攀
# @File ： 情感分析.py
# @Software : PyCharm
import csv
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
from aip import AipNlp
APP_ID = '25241652'
API_KEY = 'AarC0lsmRrdrS2dIEGmpvDGK'
SECRET_KEY = 'MoFEfWdQadecVdqyIEFRGbqP4LxAKaZz'
client = AipNlp(APP_ID, API_KEY, SECRET_KEY)

fp = open('天猫+999+处理完+.csv', 'w+', newline='', encoding='utf-8')
write = csv.writer(fp)
text= '"LH价格也很划算??,药比药店便宜??,相当不错的选择?,和药店里买的999一样的?,有防伪标识?,买几盒在家有备无患12??,阿里大药房还是不错的??,这次用了红包更便宜??,喝着暖暖的特别舒服??,效果一样的?,看起来应该是正品?,想不到那么快就到了！五星好评超赞??,为了预防冬天感冒?,咳品感冒上午收到了了??"'
print(text[19])
sentiment = client.sentimentClassify(text)
print(sentiment['items'][0]['positive_prob'])
write.writerow(str(sentiment['items'][0]['sentiment']))
fp.close()
doc_set = []
with open('天猫+999.csv', "r", encoding='utf-8') as f:  # 打开文件
    read = csv.reader(f)
    for line in read:
        doc_set.append(line[1])
print(doc_set)