# coding:utf-8
# @Time : 2021/11/11 16:00
# @Author : 郑攀
# @File ： 天猫评论爬取.py
# @Software : PyCharm
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import urllib.request
import json
import time
import csv
import random

# ======》爬取评论信息《=======#

fp = open('天猫+复方氨酚烷胺片.csv', 'a+', newline='', encoding='utf-8')
write = csv.writer(fp)
# end_page = int(input('请输入爬取的结束页码:'))
end_page = 99
for i in range(95, end_page):
    print('第%s页开始爬取------' % (i + 1))
    url ='https://rate.tmall.com/list_detail_rate.htm?itemId=539048757318&spuId=265588647&sellerId=2928278102&order=3&currentPage={}&append=0&content=1&tagId=&posi=&picture=&groupId=&ua=098#E1hvrQvBvo9vUpCkvvvvvjiWPsSZgjiUnLsvAj3mPmPUQjrWR2MhsjibnLFOsj38Rs9Cvvpvvvvv9vhvHnMz5qz07rMNzYktMHlQz1PN/nsvdvhvmpvWEUNsGQCGzuQCvvyv2jGU8A+v789gvpvhvvvvvUvCvvsNYYTYlDsNzYYOUaA+vpvEvvs5mH1wv23P39hvCvvhvvvgvpvhvvvvvvvCvvOvCvvvphvUvpCW2vCevvay3w0x9C+aWDNBlwethbUfb5c60f06WeCp+Exr08TJEcqpafmxdB+aUExr0j7xh7ERD7zpaXTrjLVxfJBl533+CNLO0RowHd9Cvm9vvvvPphvvvvvvvYxvpvAQvvv2vhCv2UhvvvWvphvWmpvvvQCvpvQEuvhvmvvv9bgjaRewkvhvC99vvOCtLvgCvvLMMQvvi9hvCvvv9U8+vpvEvv1WvdV1vC9i&needFold=0&_ksTS=1637581298548_675&callback=jsonp676'
    url = url.format(i+1)
    # print(url)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36 Edg/95.0.1020.44',
        'Referer':'https://detail.tmall.com/item.htm?id=539048757318&rn=2e69f0f507293db67e3d5461e1317bda&abbucket=15',
        'Cookie':'cna=p/RtGcypE1ECAT3ylQDbqSPX; hng=CN|zh-CN|CNY|156; lid=t_1503624415161_0876; t=5e14948b9228561e59679d8c5b8f30c0; tracknick=t_1503624415161_0876; lgc=t_1503624415161_0876; _tb_token_=f563967631358; cookie2=12c17cc267e12936260be276af09fe45; _m_h5_tk=c8d711af63f6b7c956de0cf819b9a8e4_1637559788465; _m_h5_tk_enc=f3fd20293b3098cfda60889d9cc08c40; dnk=t_1503624415161_0876; login=true; cancelledSubSites=empty; uc1=cookie16=URm48syIJ1yk0MX2J7mAAEhTuw==&existShop=false&cookie21=Vq8l+KCLjhS4UhJVbCU7&cookie14=Uoe3cOjuRhR3zw==&pas=0&cookie15=URm48syIIVrSKA==; uc3=vt3=F8dCvUj9WIiOHVU0X84=&id2=UNN+xyh6579tUw==&nk2=F6k3HSxu+F5AI4aPukyvuKvcPL0=&lg2=VFC/uZ9ayeYq2g==; uc4=nk4=0@FbMocxnJdwHEq/1feJXESkPx9ikklcg/C6tpS8FUow==&id4=0@UgQ2gbMUREdBRqa1ZdR1JFBpUcIb; sgcookie=E100gEDZwXWh4vFWXbpkwrJCgnJoh0aXZQFGO4a65eZENdNOO8LHJ+FvMUC2+GXtzuaduLiBVbs/HT+8xUCmGTmX3PW7YNOvXXxccZFhLpWeEd0=; csg=bfb84796; enc=I0AOZ97a27l4OMurR9Cn/xzIZQHHXdCJ8J9O9G6N+tShupEVvWfJGpG8ZrCluP+95khAb2991Y8gQjIOeKY3/g==; x5sec=7b22617365727665723b32223a22643962366639333263373139333262323831646465396634343462303166623543495379376f7747454e4c5475744c63676235584767307a4d7a4d784e5455354e7a55344f7a45334b414977727148786a51493d227d; tfstk=ch6lBbVGK_R7oAAc1895DOOfkU6lZxFyP9WV3O5xrSsv3e6Vibcq_LFYmUU_zX1..; l=eBE8dCh4j880zCXfBOfanurza77tJIR4YuPzaNbMiOCP_X5w5yDPW6BigOYeCn1Vns1XR3ulSEjUBX8UXyzhlZXRFJXn9MptEdLh.; isg=BF1db3fU4GeSSIU3rCT_lVWYbDlXepHM0SIVLR8iprTj1n8I58tQnaVAAEpQDamE'
    }

    request = urllib.request.Request(url=url, headers=headers)
    content = urllib.request.urlopen(request).read().decode('UTF-8')
    # print(content)
    content = content[13:-1]
    # print(content)
    obj = json.loads(content)
    comments = obj['rateDetail']['rateList']
    # print(comments)
    for comment in comments:
        # 评论时间
        creationTime = comment['rateDate']
        # 评论人
        nickname = comment['displayUserNick']
        # 评论内容
        contents = comment['rateContent']
        # 用户ID
        id = comment['id']

        result = [creationTime,contents]
        write.writerow(result)
    print('第%s页完成----------' % (i + 1))
    a = random.random()
    time.sleep(10+0.5*a)

fp.close()
